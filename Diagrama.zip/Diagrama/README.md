@startuml
left to right direction


abstract class BaseEntity {
    + Boolean state
    + LocalDateTime createdAt
    + LocalDateTime updatedAt
    + LocalDateTime deletedAt
    + Integer createdBy
    + Integer updatedBy
    + Integer deletedBy
}

interface CRUD {
    + create(BaseEntity entity)
    + read(Integer id) : BaseEntity
    + update(BaseEntity entity, Integer id)
    + delete(Integer id)
}

package "Seguridad" {
    class Persona extends BaseEntity implements CRUD {
        + String tipoDocumento
        + String numeroDocumento
        + String nombres
        + String apellidos
        + String correoElectronico
        + String telefono
        + String direccion
    }

    class Usuario extends BaseEntity implements CRUD {
        + String nombreUsuario
        + String contraseña
        - Persona persona
    }

    class Rol extends BaseEntity implements CRUD {
        + String codigo
        + String nombre
        + String descripcion
    }

    class UsuarioRol extends BaseEntity implements CRUD {
        - Usuario usuario
        - Rol rol
    }

    
    Persona "1" -- "1" Usuario : "asociado a"
    Usuario "1" -- "*" UsuarioRol : "tiene rol"
    Rol "1" -- "*" UsuarioRol : "es asignado a"
}

package "Inventario" {
    class Categoria extends BaseEntity implements CRUD {
        + String codigo
        + String nombre
        + String descripcion
    }

    class Producto extends BaseEntity implements CRUD {
        + String codigo
        + String nombre
        + String descripcion
        - Categoria categoria
    }

    class Inventario extends BaseEntity implements CRUD {
        + int stock
        + Decimal valorCompra
        + Decimal valorVenta
        - Producto producto
    }

    
    Categoria "1" -- "*" Producto : "clasifica"
    Producto "1" -- "*" Inventario : "es registrado en"
}


package "Proveedores" {
    class Empresa extends BaseEntity implements CRUD {
        + String numeroIdentificacion
        + String nombre
        + String direccion
        + String correoElectronico
        + String telefono
        + String identificadorGerente
    }

    class Sucursal extends BaseEntity implements CRUD {
        + String nombre
        + String direccion
        + String correoElectronico
        + String telefono
        + String responsable
        - Empresa empresa
    }

    
    Empresa "1" -- "*" Sucursal : "posee"
}


package "Facturación" {
    class Factura extends BaseEntity implements CRUD {
        + LocalDateTime fechaVenta
        + Decimal valorBruto
        + Decimal valorNeto
        + Decimal descuento
        + String metodoPago
        - Usuario usuario
    }

    class DetalleFactura extends BaseEntity implements CRUD {
        + int cantidad
        + Decimal valorBruto
        + Decimal valorNeto
        + Decimal porcentajeDescuento
        - Factura factura
        - Producto producto
    }

    class MedioPago extends BaseEntity implements CRUD {
        + String codigo
        + String nombre
        + String descripcion
    }

    
    Factura "1" -- "*" DetalleFactura : "incluye"
    Producto "1" -- "*" DetalleFactura : "se detalla en"
    MedioPago "1" -- "*" Factura : "se utiliza en"
}

@enduml
![diagrama](/diagrama.jpg)
